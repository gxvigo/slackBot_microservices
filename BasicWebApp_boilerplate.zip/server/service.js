'use strict'   // use ES6 strict mode

const express = require('express');
const service = express();

module.exports = service; 

